import os
import json
import boto3
import datetime

dynamodb = boto3.resource('dynamodb')
table_name = os.environ['DYNAMODB_TABLE']
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    # Logging Input Event (for debugging)
    print("Received event:", json.dumps(event))

    try:
        body = json.loads(event["body"])
        user_id = body["userId"]
        feedback_text = body["feedback"]

        timestamp = datetime.datetime.utcnow().isoformat()

        # Basic validation
        if not feedback_text:
            return {
                "statusCode": 400,
                "body": json.dumps({"message": "Feedback must not be empty"})
            }

        # Save to DynamoDB
        table.put_item(Item={
            "userId": user_id,
            "timestamp": timestamp,
            "feedback": feedback_text
        })

        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Feedback submitted"})
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Internal server error"})
        }
